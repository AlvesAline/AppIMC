import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
    footer: {
        backgroundColor:'#b0baa3',
        width:'100%',
        fontSize:20,
        fontWeight: 'bold',
        color: 'white',
        padding:10,
        textAlign: 'center'
    }
})